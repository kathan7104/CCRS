package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Basic smoke test to ensure the Spring context loads.
 */
@SpringBootTest
class ScrsApplicationTests {

	@Test
	void contextLoads() {
	}

}
